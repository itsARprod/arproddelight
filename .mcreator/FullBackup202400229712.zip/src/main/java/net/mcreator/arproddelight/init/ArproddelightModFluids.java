
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.arproddelight.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.arproddelight.fluid.MeltedCheeseFluid;
import net.mcreator.arproddelight.fluid.CreamFluid;
import net.mcreator.arproddelight.ArproddelightMod;

public class ArproddelightModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, ArproddelightMod.MODID);
	public static final RegistryObject<FlowingFluid> MELTED_CHEESE = REGISTRY.register("melted_cheese", () -> new MeltedCheeseFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_MELTED_CHEESE = REGISTRY.register("flowing_melted_cheese", () -> new MeltedCheeseFluid.Flowing());
	public static final RegistryObject<FlowingFluid> CREAM = REGISTRY.register("cream", () -> new CreamFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_CREAM = REGISTRY.register("flowing_cream", () -> new CreamFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(MELTED_CHEESE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_MELTED_CHEESE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(CREAM.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_CREAM.get(), RenderType.translucent());
		}
	}
}
