
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.arproddelight.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.arproddelight.block.WildCoffeaBlock;
import net.mcreator.arproddelight.block.TonirBlock;
import net.mcreator.arproddelight.block.SprueLeavesRedBaubleBlock;
import net.mcreator.arproddelight.block.SpruceLeavesYellowBaubleBlock;
import net.mcreator.arproddelight.block.SpruceLeavesBlueBaubleBlock;
import net.mcreator.arproddelight.block.SalamiPizzaBlock;
import net.mcreator.arproddelight.block.MeltedCheeseBlock;
import net.mcreator.arproddelight.block.MargheritaPizzaBlock;
import net.mcreator.arproddelight.block.CreamBlock;
import net.mcreator.arproddelight.block.CheeseBlockBlock;
import net.mcreator.arproddelight.block.CandyCaneBlockBlock;
import net.mcreator.arproddelight.block.BoscaiolaPizzaBlock;
import net.mcreator.arproddelight.block.BananaCrateBlock;
import net.mcreator.arproddelight.ArproddelightMod;

public class ArproddelightModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ArproddelightMod.MODID);
	public static final RegistryObject<Block> MELTED_CHEESE = REGISTRY.register("melted_cheese", () -> new MeltedCheeseBlock());
	public static final RegistryObject<Block> CHEESE_BLOCK = REGISTRY.register("cheese_block", () -> new CheeseBlockBlock());
	public static final RegistryObject<Block> MARGHERITA_PIZZA = REGISTRY.register("margherita_pizza", () -> new MargheritaPizzaBlock());
	public static final RegistryObject<Block> SALAMI_PIZZA = REGISTRY.register("salami_pizza", () -> new SalamiPizzaBlock());
	public static final RegistryObject<Block> BOSCAIOLA_PIZZA = REGISTRY.register("boscaiola_pizza", () -> new BoscaiolaPizzaBlock());
	public static final RegistryObject<Block> TONIR = REGISTRY.register("tonir", () -> new TonirBlock());
	public static final RegistryObject<Block> CREAM = REGISTRY.register("cream", () -> new CreamBlock());
	public static final RegistryObject<Block> WILD_COFFEA = REGISTRY.register("wild_coffea", () -> new WildCoffeaBlock());
	public static final RegistryObject<Block> BANANA_CRATE = REGISTRY.register("banana_crate", () -> new BananaCrateBlock());
	public static final RegistryObject<Block> CANDY_CANE_BLOCK = REGISTRY.register("candy_cane_block", () -> new CandyCaneBlockBlock());
	public static final RegistryObject<Block> SPRUCE_LEAVES_RED_BAUBLE = REGISTRY.register("spruce_leaves_red_bauble", () -> new SprueLeavesRedBaubleBlock());
	public static final RegistryObject<Block> SPRUCE_LEAVES_BLUE_BAUBLE = REGISTRY.register("spruce_leaves_blue_bauble", () -> new SpruceLeavesBlueBaubleBlock());
	public static final RegistryObject<Block> SPRUCE_LEAVES_YELLOW_BAUBLE = REGISTRY.register("spruce_leaves_yellow_bauble", () -> new SpruceLeavesYellowBaubleBlock());

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			SprueLeavesRedBaubleBlock.blockColorLoad(event);
			SpruceLeavesBlueBaubleBlock.blockColorLoad(event);
			SpruceLeavesYellowBaubleBlock.blockColorLoad(event);
		}

		@SubscribeEvent
		public static void itemColorLoad(RegisterColorHandlersEvent.Item event) {
			SprueLeavesRedBaubleBlock.itemColorLoad(event);
			SpruceLeavesBlueBaubleBlock.itemColorLoad(event);
			SpruceLeavesYellowBaubleBlock.itemColorLoad(event);
		}
	}
}
