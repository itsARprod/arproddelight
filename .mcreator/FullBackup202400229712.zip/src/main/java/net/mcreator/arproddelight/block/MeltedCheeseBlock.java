
package net.mcreator.arproddelight.block;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.arproddelight.init.ArproddelightModFluids;

public class MeltedCheeseBlock extends LiquidBlock {
	public MeltedCheeseBlock() {
		super(() -> ArproddelightModFluids.MELTED_CHEESE.get(), BlockBehaviour.Properties.of().mapColor(MapColor.WATER).strength(100f).noCollission().noLootTable().liquid().pushReaction(PushReaction.DESTROY).sound(SoundType.EMPTY).replaceable());
	}
}
