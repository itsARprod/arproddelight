
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.arproddelight.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.arproddelight.fluid.types.MeltedCheeseFluidType;
import net.mcreator.arproddelight.fluid.types.CreamFluidType;
import net.mcreator.arproddelight.ArproddelightMod;

public class ArproddelightModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, ArproddelightMod.MODID);
	public static final RegistryObject<FluidType> MELTED_CHEESE_TYPE = REGISTRY.register("melted_cheese", () -> new MeltedCheeseFluidType());
	public static final RegistryObject<FluidType> CREAM_TYPE = REGISTRY.register("cream", () -> new CreamFluidType());
}
