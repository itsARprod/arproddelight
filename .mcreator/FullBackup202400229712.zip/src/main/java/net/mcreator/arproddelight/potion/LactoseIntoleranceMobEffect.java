
package net.mcreator.arproddelight.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.arproddelight.procedures.LactoseIntoleranceActiveTickConditionProcedure;

public class LactoseIntoleranceMobEffect extends MobEffect {
	public LactoseIntoleranceMobEffect() {
		super(MobEffectCategory.HARMFUL, -1052673);
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		LactoseIntoleranceActiveTickConditionProcedure.execute(entity);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
