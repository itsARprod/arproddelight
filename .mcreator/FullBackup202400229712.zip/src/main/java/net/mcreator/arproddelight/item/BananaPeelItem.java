
package net.mcreator.arproddelight.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class BananaPeelItem extends Item {
	public BananaPeelItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
