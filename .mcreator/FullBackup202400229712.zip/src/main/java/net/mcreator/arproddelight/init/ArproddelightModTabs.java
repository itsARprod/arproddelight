
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.arproddelight.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.arproddelight.ArproddelightMod;

public class ArproddelightModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ArproddelightMod.MODID);
	public static final RegistryObject<CreativeModeTab> A_RPRODS_DELIGHT = REGISTRY.register("a_rprods_delight",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.arproddelight.a_rprods_delight")).icon(() -> new ItemStack(ArproddelightModItems.CANDY_CANE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(ArproddelightModItems.CUT_POTATOES.get());
				tabData.accept(ArproddelightModItems.FRIED_CUT_POTATOES.get());
				tabData.accept(ArproddelightModItems.MELTED_CHEESE_BUCKET.get());
				tabData.accept(ArproddelightModItems.CHEESE.get());
				tabData.accept(ArproddelightModBlocks.CHEESE_BLOCK.get().asItem());
				tabData.accept(ArproddelightModItems.GRILLED_CHEESE_SANDWICH.get());
				tabData.accept(ArproddelightModItems.CHEESEBURGER.get());
				tabData.accept(ArproddelightModItems.DOUBLE_HAMBURGER.get());
				tabData.accept(ArproddelightModItems.MAC_N_CHEESE.get());
				tabData.accept(ArproddelightModItems.UZBEK_RICE.get());
				tabData.accept(ArproddelightModItems.SALAMI.get());
				tabData.accept(ArproddelightModBlocks.MARGHERITA_PIZZA.get().asItem());
				tabData.accept(ArproddelightModBlocks.SALAMI_PIZZA.get().asItem());
				tabData.accept(ArproddelightModBlocks.BOSCAIOLA_PIZZA.get().asItem());
				tabData.accept(ArproddelightModBlocks.TONIR.get().asItem());
				tabData.accept(ArproddelightModItems.LAVASH.get());
				tabData.accept(ArproddelightModItems.RAW_BEEF_LAHMAJO.get());
				tabData.accept(ArproddelightModItems.BEEF_LAHMAJO.get());
				tabData.accept(ArproddelightModItems.CHEESE_AND_TOMATO_DURUM.get());
				tabData.accept(ArproddelightModItems.CREAM_BUCKET.get());
				tabData.accept(ArproddelightModItems.ICE_CREAM_CONE.get());
				tabData.accept(ArproddelightModItems.ICE_CREAM_CREAM.get());
				tabData.accept(ArproddelightModItems.ICE_CREAM_CREAM_CHERRY.get());
				tabData.accept(ArproddelightModItems.ICE_CREAM_CHOCOLATE.get());
				tabData.accept(ArproddelightModItems.ICE_CREAM_HONEY.get());
				tabData.accept(ArproddelightModItems.BANANA.get());
				tabData.accept(ArproddelightModItems.BANANA_PEEL.get());
				tabData.accept(ArproddelightModItems.GRATER.get());
				tabData.accept(ArproddelightModItems.GRATED_CHEESE.get());
				tabData.accept(ArproddelightModItems.CHERRY.get());
				tabData.accept(ArproddelightModBlocks.WILD_COFFEA.get().asItem());
				tabData.accept(ArproddelightModItems.COFFEE_BERRY.get());
				tabData.accept(ArproddelightModItems.COFFEE_BEAN.get());
				tabData.accept(ArproddelightModItems.RAW_CLAY_CUP.get());
				tabData.accept(ArproddelightModItems.CLAY_CUP.get());
				tabData.accept(ArproddelightModItems.COFFEE_CUP.get());
				tabData.accept(ArproddelightModItems.BANANAXE.get());
				tabData.accept(ArproddelightModBlocks.BANANA_CRATE.get().asItem());
				tabData.accept(ArproddelightModItems.CANDY_CANE.get());
				tabData.accept(ArproddelightModItems.CANDY_SPEAR.get());
				tabData.accept(ArproddelightModBlocks.CANDY_CANE_BLOCK.get().asItem());
				tabData.accept(ArproddelightModItems.RED_BAUBLE.get());
				tabData.accept(ArproddelightModItems.BLUE_BAUBLE.get());
				tabData.accept(ArproddelightModItems.YELLOW_BAUBLE.get());
				tabData.accept(ArproddelightModBlocks.SPRUCE_LEAVES_RED_BAUBLE.get().asItem());
				tabData.accept(ArproddelightModBlocks.SPRUCE_LEAVES_BLUE_BAUBLE.get().asItem());
				tabData.accept(ArproddelightModBlocks.SPRUCE_LEAVES_YELLOW_BAUBLE.get().asItem());
				tabData.accept(ArproddelightModItems.KHINKALI.get());
				tabData.accept(ArproddelightModItems.CAKE_DOUGH.get());
			})

					.build());
}
