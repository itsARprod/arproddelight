
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.arproddelight.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.arproddelight.item.YellowBaubleItem;
import net.mcreator.arproddelight.item.UzbekRiceItem;
import net.mcreator.arproddelight.item.UnfinishedPizzaItem;
import net.mcreator.arproddelight.item.SalamiItem;
import net.mcreator.arproddelight.item.RedBaubleItem;
import net.mcreator.arproddelight.item.RawClayCupItem;
import net.mcreator.arproddelight.item.RawBeefLahmajoItem;
import net.mcreator.arproddelight.item.MeltedCheeseItem;
import net.mcreator.arproddelight.item.MacNCheeseItem;
import net.mcreator.arproddelight.item.LavashItem;
import net.mcreator.arproddelight.item.KhinkaliItem;
import net.mcreator.arproddelight.item.IceCreamItem;
import net.mcreator.arproddelight.item.IceCreamHoneyItem;
import net.mcreator.arproddelight.item.IceCreamCreamCherryItem;
import net.mcreator.arproddelight.item.IceCreamConeItem;
import net.mcreator.arproddelight.item.IceCreamChocolateItem;
import net.mcreator.arproddelight.item.GrilledCheeseSandwichItem;
import net.mcreator.arproddelight.item.GraterItem;
import net.mcreator.arproddelight.item.GratedCheeseItem;
import net.mcreator.arproddelight.item.FriedCutPotatoesItem;
import net.mcreator.arproddelight.item.DoubleHamburgerItem;
import net.mcreator.arproddelight.item.CutPotatoesItem;
import net.mcreator.arproddelight.item.CreamItem;
import net.mcreator.arproddelight.item.CoffeeCupItem;
import net.mcreator.arproddelight.item.CoffeeBerryItem;
import net.mcreator.arproddelight.item.CoffeeBeanItem;
import net.mcreator.arproddelight.item.ClayCupItem;
import net.mcreator.arproddelight.item.CherryItem;
import net.mcreator.arproddelight.item.CheeseburgerItem;
import net.mcreator.arproddelight.item.CheeseItem;
import net.mcreator.arproddelight.item.CheeseAndTomatoDurumItem;
import net.mcreator.arproddelight.item.CandySpearItem;
import net.mcreator.arproddelight.item.CandyCaneItem;
import net.mcreator.arproddelight.item.CakeDoughItem;
import net.mcreator.arproddelight.item.BlueBaubleItem;
import net.mcreator.arproddelight.item.BeefLahmajoItem;
import net.mcreator.arproddelight.item.BananaxeItem;
import net.mcreator.arproddelight.item.BananaPeelItem;
import net.mcreator.arproddelight.item.BananaItem;
import net.mcreator.arproddelight.ArproddelightMod;

public class ArproddelightModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ArproddelightMod.MODID);
	public static final RegistryObject<Item> CUT_POTATOES = REGISTRY.register("cut_potatoes", () -> new CutPotatoesItem());
	public static final RegistryObject<Item> FRIED_CUT_POTATOES = REGISTRY.register("fried_cut_potatoes", () -> new FriedCutPotatoesItem());
	public static final RegistryObject<Item> MELTED_CHEESE_BUCKET = REGISTRY.register("melted_cheese_bucket", () -> new MeltedCheeseItem());
	public static final RegistryObject<Item> CHEESE = REGISTRY.register("cheese", () -> new CheeseItem());
	public static final RegistryObject<Item> CHEESE_BLOCK = block(ArproddelightModBlocks.CHEESE_BLOCK);
	public static final RegistryObject<Item> GRILLED_CHEESE_SANDWICH = REGISTRY.register("grilled_cheese_sandwich", () -> new GrilledCheeseSandwichItem());
	public static final RegistryObject<Item> CHEESEBURGER = REGISTRY.register("cheeseburger", () -> new CheeseburgerItem());
	public static final RegistryObject<Item> MARGHERITA_PIZZA = block(ArproddelightModBlocks.MARGHERITA_PIZZA);
	public static final RegistryObject<Item> UNFINISHED_PIZZA = REGISTRY.register("unfinished_pizza", () -> new UnfinishedPizzaItem());
	public static final RegistryObject<Item> SALAMI = REGISTRY.register("salami", () -> new SalamiItem());
	public static final RegistryObject<Item> SALAMI_PIZZA = block(ArproddelightModBlocks.SALAMI_PIZZA);
	public static final RegistryObject<Item> BOSCAIOLA_PIZZA = block(ArproddelightModBlocks.BOSCAIOLA_PIZZA);
	public static final RegistryObject<Item> MAC_N_CHEESE = REGISTRY.register("mac_n_cheese", () -> new MacNCheeseItem());
	public static final RegistryObject<Item> TONIR = block(ArproddelightModBlocks.TONIR);
	public static final RegistryObject<Item> LAVASH = REGISTRY.register("lavash", () -> new LavashItem());
	public static final RegistryObject<Item> DOUBLE_HAMBURGER = REGISTRY.register("double_hamburger", () -> new DoubleHamburgerItem());
	public static final RegistryObject<Item> CHEESE_AND_TOMATO_DURUM = REGISTRY.register("cheese_and_tomato_durum", () -> new CheeseAndTomatoDurumItem());
	public static final RegistryObject<Item> UZBEK_RICE = REGISTRY.register("uzbek_rice", () -> new UzbekRiceItem());
	public static final RegistryObject<Item> CREAM_BUCKET = REGISTRY.register("cream_bucket", () -> new CreamItem());
	public static final RegistryObject<Item> ICE_CREAM_CONE = REGISTRY.register("ice_cream_cone", () -> new IceCreamConeItem());
	public static final RegistryObject<Item> ICE_CREAM_CREAM = REGISTRY.register("ice_cream_cream", () -> new IceCreamItem());
	public static final RegistryObject<Item> ICE_CREAM_CHOCOLATE = REGISTRY.register("ice_cream_chocolate", () -> new IceCreamChocolateItem());
	public static final RegistryObject<Item> RAW_BEEF_LAHMAJO = REGISTRY.register("raw_beef_lahmajo", () -> new RawBeefLahmajoItem());
	public static final RegistryObject<Item> BEEF_LAHMAJO = REGISTRY.register("beef_lahmajo", () -> new BeefLahmajoItem());
	public static final RegistryObject<Item> ICE_CREAM_HONEY = REGISTRY.register("ice_cream_honey", () -> new IceCreamHoneyItem());
	public static final RegistryObject<Item> BANANA = REGISTRY.register("banana", () -> new BananaItem());
	public static final RegistryObject<Item> BANANA_PEEL = REGISTRY.register("banana_peel", () -> new BananaPeelItem());
	public static final RegistryObject<Item> GRATER = REGISTRY.register("grater", () -> new GraterItem());
	public static final RegistryObject<Item> GRATED_CHEESE = REGISTRY.register("grated_cheese", () -> new GratedCheeseItem());
	public static final RegistryObject<Item> CHERRY = REGISTRY.register("cherry", () -> new CherryItem());
	public static final RegistryObject<Item> ICE_CREAM_CREAM_CHERRY = REGISTRY.register("ice_cream_cream_cherry", () -> new IceCreamCreamCherryItem());
	public static final RegistryObject<Item> WILD_COFFEA = block(ArproddelightModBlocks.WILD_COFFEA);
	public static final RegistryObject<Item> COFFEE_BERRY = REGISTRY.register("coffee_berry", () -> new CoffeeBerryItem());
	public static final RegistryObject<Item> COFFEE_BEAN = REGISTRY.register("coffee_bean", () -> new CoffeeBeanItem());
	public static final RegistryObject<Item> RAW_CLAY_CUP = REGISTRY.register("raw_clay_cup", () -> new RawClayCupItem());
	public static final RegistryObject<Item> CLAY_CUP = REGISTRY.register("clay_cup", () -> new ClayCupItem());
	public static final RegistryObject<Item> COFFEE_CUP = REGISTRY.register("coffee_cup", () -> new CoffeeCupItem());
	public static final RegistryObject<Item> BANANAXE = REGISTRY.register("bananaxe", () -> new BananaxeItem());
	public static final RegistryObject<Item> BANANA_CRATE = block(ArproddelightModBlocks.BANANA_CRATE);
	public static final RegistryObject<Item> CANDY_CANE = REGISTRY.register("candy_cane", () -> new CandyCaneItem());
	public static final RegistryObject<Item> CANDY_SPEAR = REGISTRY.register("candy_spear", () -> new CandySpearItem());
	public static final RegistryObject<Item> CANDY_CANE_BLOCK = block(ArproddelightModBlocks.CANDY_CANE_BLOCK);
	public static final RegistryObject<Item> RED_BAUBLE = REGISTRY.register("red_bauble", () -> new RedBaubleItem());
	public static final RegistryObject<Item> BLUE_BAUBLE = REGISTRY.register("blue_bauble", () -> new BlueBaubleItem());
	public static final RegistryObject<Item> YELLOW_BAUBLE = REGISTRY.register("yellow_bauble", () -> new YellowBaubleItem());
	public static final RegistryObject<Item> SPRUCE_LEAVES_RED_BAUBLE = block(ArproddelightModBlocks.SPRUCE_LEAVES_RED_BAUBLE);
	public static final RegistryObject<Item> SPRUCE_LEAVES_BLUE_BAUBLE = block(ArproddelightModBlocks.SPRUCE_LEAVES_BLUE_BAUBLE);
	public static final RegistryObject<Item> SPRUCE_LEAVES_YELLOW_BAUBLE = block(ArproddelightModBlocks.SPRUCE_LEAVES_YELLOW_BAUBLE);
	public static final RegistryObject<Item> KHINKALI = REGISTRY.register("khinkali", () -> new KhinkaliItem());
	public static final RegistryObject<Item> CAKE_DOUGH = REGISTRY.register("cake_dough", () -> new CakeDoughItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
