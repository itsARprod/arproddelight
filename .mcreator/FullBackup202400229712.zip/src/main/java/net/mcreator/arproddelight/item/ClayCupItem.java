
package net.mcreator.arproddelight.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class ClayCupItem extends Item {
	public ClayCupItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
