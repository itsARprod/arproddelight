
package net.mcreator.arproddelight.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class BlueBaubleItem extends Item {
	public BlueBaubleItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
