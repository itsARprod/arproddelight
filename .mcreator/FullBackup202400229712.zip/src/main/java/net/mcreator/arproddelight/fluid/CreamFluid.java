
package net.mcreator.arproddelight.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.arproddelight.init.ArproddelightModItems;
import net.mcreator.arproddelight.init.ArproddelightModFluids;
import net.mcreator.arproddelight.init.ArproddelightModFluidTypes;
import net.mcreator.arproddelight.init.ArproddelightModBlocks;

public abstract class CreamFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> ArproddelightModFluidTypes.CREAM_TYPE.get(), () -> ArproddelightModFluids.CREAM.get(), () -> ArproddelightModFluids.FLOWING_CREAM.get())
			.explosionResistance(100f).bucket(() -> ArproddelightModItems.CREAM_BUCKET.get()).block(() -> (LiquidBlock) ArproddelightModBlocks.CREAM.get());

	private CreamFluid() {
		super(PROPERTIES);
	}

	public static class Source extends CreamFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends CreamFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
